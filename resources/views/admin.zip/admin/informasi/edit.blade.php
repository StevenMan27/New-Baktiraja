@extends('layouts.admin')

@section('title', 'Edit Informasi')

@section('content')

<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

    :root {
        --navy: #003366;
        --navy-light: #1a4a7a;
        --gold: #c6a43b;
        --surface: #ffffff;
        --surface-2: #f8fafc;
        --border: #e2e8f0;
        --text: #1e293b;
        --text-muted: #64748b;
        --danger: #ef4444;
        --success: #22c55e;
        --radius: 14px;
        --radius-sm: 8px;
        --shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 24px rgba(0,51,102,0.10);
    }

    /* Mengatur font global seluruh halaman dan elemen form menggunakan Plus Jakarta Sans */
    body, input, textarea, select, button {
        font-family: 'Plus Jakarta Sans', sans-serif !important;
    }

    /* Wrapper utama halaman tanpa batas lebar agar konten melebar penuh */
    .ep-wrapper {
        max-width: 100%;
        margin: 0;
        padding: 0 0 60px;
    }

    /* Banner header halaman dengan latar gradient biru gelap */
    .hp-page-header {
        background: linear-gradient(135deg, var(--navy) 0%, var(--navy-light) 100%);
        border-radius: var(--radius);
        padding: 28px 32px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        margin-bottom: 28px;
        box-shadow: var(--shadow-md);
        position: relative;
        overflow: hidden;
    }

    /* Dekorasi lingkaran besar transparan di pojok kanan atas header */
    .hp-page-header::before {
        content: '';
        position: absolute;
        top: -40px;
        right: -40px;
        width: 160px;
        height: 160px;
        background: rgba(255,255,255,0.05);
        border-radius: 50%;
    }

    /* Dekorasi lingkaran kecil transparan di pojok kiri bawah header */
    .hp-page-header::after {
        content: '';
        position: absolute;
        bottom: -30px;
        left: 120px;
        width: 100px;
        height: 100px;
        background: rgba(255,255,255,0.04);
        border-radius: 50%;
    }

    /* Wrapper sisi kiri header yang menampung ikon dan teks judul */
    .hp-page-header-left {
        display: flex;
        align-items: center;
        gap: 18px;
        position: relative;
        z-index: 1;
    }

    /* Kotak ikon persegi di sisi kiri header */
    .hp-page-header .icon-wrap {
        width: 52px;
        height: 52px;
        background: rgba(255,255,255,0.12);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
        color: #fff;
        flex-shrink: 0;
    }

    /* Judul utama halaman di dalam header */
    .hp-page-header h4 {
        color: #fff;
        margin: 0;
        font-weight: 700;
        font-size: 1.2rem;
    }

    /* Subjudul kecil di bawah judul header */
    .hp-page-header p {
        color: rgba(255,255,255,0.65);
        margin: 0;
        font-size: 0.85rem;
    }

    /* Tombol kembali di sisi kanan header dengan tampilan transparan */
    .hp-btn-back {
        background: rgba(255,255,255,0.13);
        color: #fff;
        border: 1.5px solid rgba(255,255,255,0.25);
        padding: 9px 20px;
        border-radius: 50px;
        font-size: 0.82rem;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 7px;
        text-decoration: none;
        transition: background 0.2s;
        white-space: nowrap;
        position: relative;
        z-index: 1;
    }

    /* Efek hover tombol kembali memperterang latar belakang */
    .hp-btn-back:hover {
        background: rgba(255,255,255,0.22);
        color: #fff;
    }

    /* Card section pembungkus kelompok input form */
    .hp-section {
        background: var(--surface);
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        margin-bottom: 20px;
        overflow: hidden;
    }

    /* Header bagian atas setiap section card */
    .hp-section-header {
        padding: 18px 24px;
        border-bottom: 1px solid var(--border);
        display: flex;
        align-items: center;
        gap: 12px;
        background: var(--surface-2);
    }

    /* Kotak ikon kecil di kiri header section */
    .hp-section-header .section-icon {
        width: 36px;
        height: 36px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.95rem;
        flex-shrink: 0;
    }

    /* Judul section card */
    .hp-section-header h6 {
        margin: 0;
        font-size: 0.95rem;
        font-weight: 700;
        color: var(--text);
    }

    /* Deskripsi kecil di bawah judul section */
    .hp-section-header p {
        margin: 0;
        font-size: 0.78rem;
        color: var(--text-muted);
    }

    /* Padding konten di dalam body setiap section */
    .hp-section-body {
        padding: 24px;
    }

    /* Warna ikon section informasi dasar berwarna biru */
    .icon-info    { background: #eff6ff; color: #2563eb; }

    /* Warna ikon section konten berwarna hijau */
    .icon-content { background: #f0fdf4; color: #16a34a; }

    /* Warna ikon section gambar berwarna ungu */
    .icon-media   { background: #fdf4ff; color: #9333ea; }

    /* Label di atas setiap input field */
    .hp-label {
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--text-muted);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
        display: block;
    }

    /* Input teks, textarea, dan select standar dengan transisi fokus */
    .hp-input {
        width: 100%;
        padding: 10px 14px;
        border: 1.5px solid var(--border);
        border-radius: var(--radius-sm);
        font-size: 0.9rem;
        color: var(--text);
        background: #fff;
        transition: border-color 0.2s, box-shadow 0.2s;
        outline: none;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* Efek fokus input menampilkan border biru dan shadow tipis di sekitarnya */
    .hp-input:focus {
        border-color: var(--navy);
        box-shadow: 0 0 0 3px rgba(0,51,102,0.08);
    }

    /* Textarea dengan tinggi minimum dan hanya bisa diubah secara vertikal */
    textarea.hp-input {
        resize: vertical;
        min-height: 220px;
    }

    /* Teks error validasi merah di bawah input yang gagal */
    .hp-error {
        font-size: 0.78rem;
        color: var(--danger);
        margin-top: 5px;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    /* Border merah pada input yang memiliki kesalahan validasi */
    .hp-input.is-invalid {
        border-color: var(--danger);
    }

    /* Grid dua kolom berdampingan untuk input sejajar */
    .hp-grid-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    /* Grid menjadi satu kolom penuh di layar kecil */
    @media(max-width: 768px) {
        .hp-grid-2 { grid-template-columns: 1fr; }
    }

    /* Area upload gambar dengan border dashed dan latar abu muda */
    .upload-zone {
        border: 2px dashed var(--border);
        border-radius: var(--radius-sm);
        padding: 28px 18px;
        text-align: center;
        background: var(--surface-2);
        position: relative;
        cursor: pointer;
        transition: border-color 0.2s, background 0.2s;
    }

    /* Efek hover area upload memperlihatkan border biru dan latar lebih terang */
    .upload-zone:hover {
        border-color: var(--navy);
        background: #f0f6ff;
    }

    /* Input file tersembunyi menutupi seluruh area upload zone */
    .upload-zone input[type="file"] {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        z-index: 2;
    }

    /* Ikon besar di tengah area upload zone */
    .upload-zone .uz-icon {
        width: 48px;
        height: 48px;
        background: #e8effa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        font-size: 1.2rem;
        color: var(--navy);
    }

    /* Teks label utama di dalam upload zone */
    .upload-zone .uz-label {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text);
        margin-bottom: 4px;
    }

    /* Teks petunjuk format dan batas ukuran gambar */
    .upload-zone .uz-hint {
        font-size: 0.75rem;
        color: var(--text-muted);
    }

    /* Grid flex wrap menampilkan gambar yang sudah tersimpan di database */
    .existing-preview-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
        margin-top: 12px;
        margin-bottom: 24px;
    }

    /* Gambar tersimpan ditampilkan sesuai proporsi aslinya dengan bayangan */
    .existing-preview-grid .preview-item img {
        display: block;
        max-width: 100%;
        width: auto;
        height: auto;
        max-height: 280px;
        border-radius: 10px;
        border: 2px solid #fff;
        box-shadow: 0 4px 14px rgba(0,0,0,0.14);
    }

    /* Grid flex wrap menampilkan preview gambar baru yang dipilih sebelum disimpan */
    .new-preview-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 16px;
        justify-content: center;
        position: relative;
        z-index: 3;
        pointer-events: none;
    }

    /* Item preview gambar baru bisa diklik secara individual */
    .new-preview-grid .preview-item {
        pointer-events: auto;
    }

    /* Gambar preview baru ditampilkan sesuai proporsi aslinya dengan batas tinggi */
    .new-preview-grid .preview-item img {
        display: block;
        width: auto;
        height: auto;
        max-width: 100%;
        max-height: 200px;
        border-radius: 8px;
        border: 2px solid #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.12);
    }

    /* Bar simpan di bagian bawah form dengan border atas pemisah */
    .hp-save-bar {
        background: var(--surface);
        border-top: 1px solid var(--border);
        padding: 20px 24px;
        border-radius: 0 0 var(--radius) var(--radius);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
    }

    /* Teks petunjuk kecil di sisi kiri save bar */
    .hp-save-hint {
        font-size: 0.78rem;
        color: var(--text-muted);
    }

    /* Tombol simpan berwarna biru gradient dengan efek angkat saat hover */
    .hp-btn-save {
        background: linear-gradient(135deg, var(--navy) 0%, #0a4a8a 100%);
        color: #fff;
        border: none;
        padding: 12px 32px;
        border-radius: 50px;
        font-size: 0.9rem;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: opacity 0.2s, transform 0.1s;
        font-family: 'Plus Jakarta Sans', sans-serif;
        text-decoration: none;
    }

    /* Efek hover tombol simpan sedikit terangkat dan sedikit transparan */
    .hp-btn-save:hover {
        opacity: 0.9;
        transform: translateY(-1px);
        color: #fff;
    }

    /* Tombol batal berwarna abu di samping tombol simpan */
    .hp-btn-cancel {
        background: var(--surface-2);
        color: var(--text-muted);
        border: 1.5px solid var(--border);
        padding: 11px 24px;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: border-color 0.2s, color 0.2s;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* Efek hover tombol batal mempergelap warna border dan teks */
    .hp-btn-cancel:hover {
        border-color: var(--text-muted);
        color: var(--text);
    }
</style>

<div class="ep-wrapper">

    {{-- Banner header halaman dengan tombol kembali ke daftar informasi --}}
    <div class="hp-page-header">
        <div class="hp-page-header-left">
            <div class="icon-wrap"><i class="fas fa-info-circle"></i></div>
            <div>
                <h4>Edit Informasi</h4>
                <p>Perbarui informasi dan konten di Geosite Danau Toba</p>
            </div>
        </div>
        {{-- Tombol kembali menuju halaman daftar informasi --}}
        <a href="{{ route('admin.informasi.index') }}" class="hp-btn-back">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    {{-- Form utama pengiriman data edit informasi --}}
    <form action="{{ route('admin.informasi.update', $informasi->id) }}" method="POST" enctype="multipart/form-data" id="formInformasi">
        @csrf
        @method('PUT')

        {{-- Section informasi dasar berisi judul dan pilihan geosite --}}
        <div class="hp-section">
            <div class="hp-section-header">
                <div class="section-icon icon-info"><i class="fas fa-info-circle"></i></div>
                <div>
                    <h6>Informasi Dasar</h6>
                    <p>Judul dan geosite informasi</p>
                </div>
            </div>
            <div class="hp-section-body">
                <div style="margin-bottom: 16px;">
                    <label class="hp-label">Judul <span style="color:var(--danger)">*</span></label>
                    <input type="text" name="judul"
                        class="hp-input {{ $errors->has('judul') ? 'is-invalid' : '' }}"
                        value="{{ old('judul', $informasi->judul) }}"
                        placeholder="Masukkan judul informasi" required>
                    @error('judul')
                        <div class="hp-error"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                    @enderror
                </div>

                <div>
                    <label class="hp-label">Geosite <span style="color:var(--danger)">*</span></label>
                    <select name="geosite"
                        class="hp-input {{ $errors->has('geosite') ? 'is-invalid' : '' }}" required>
                        <option value="">-- Pilih Geosite --</option>
                        @foreach($geositeList as $slug => $label)
                            <option value="{{ $slug }}" {{ old('geosite', $informasi->geosite) == $slug ? 'selected' : '' }}>
                                {{ $label }}
                            </option>
                        @endforeach
                    </select>
                    @error('geosite')
                        <div class="hp-error"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>

        {{-- Section upload gambar informasi berisi gambar lama dan area upload baru --}}
        <div class="hp-section">
            <div class="hp-section-header">
                <div class="section-icon icon-media"><i class="fas fa-image"></i></div>
                <div>
                    <h6>Gambar Informasi</h6>
                    <p>Unggah gambar untuk informasi ini</p>
                </div>
            </div>
            <div class="hp-section-body">
                @php
                    /* Mengambil data gambar dari JSON dan menyiapkan array gambar yang ada */
                    $images = json_decode($informasi->gambar, true);
                    if (!is_array($images)) $images = $informasi->gambar ? [$informasi->gambar] : [];
                @endphp

                {{-- Tampilkan gambar yang sudah tersimpan sesuai proporsi aslinya --}}
                @if(count($images) > 0)
                <label class="hp-label">Gambar Saat Ini</label>
                <div class="existing-preview-grid">
                    @foreach($images as $img)
                        <div class="preview-item">
                            <img src="{{ str_starts_with($img, 'data:') ? $img : asset('storage/' . $img) }}" alt="Gambar">
                        </div>
                    @endforeach
                </div>
                @endif

                {{-- Area upload gambar baru sebagai pengganti gambar lama --}}
                <label class="hp-label">Upload Gambar Baru (kosongkan jika tidak diubah)</label>
                <div class="upload-zone">
                    <input type="file" name="gambar"
                        class="{{ $errors->has('gambar') || $errors->has('gambar.*') ? 'is-invalid' : '' }}"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        id="inputGambar">
                    <div class="uz-icon"><i class="fas fa-image"></i></div>
                    <div class="uz-label">Klik atau Seret Gambar ke Sini</div>
                    <div class="uz-hint">Format: JPG, PNG, WEBP &nbsp;|&nbsp; Maks. 10MB per gambar</div>
                    
                    <div class="new-preview-grid" id="previewGrid"></div>
                </div>
                @error('gambar')
                    <div class="hp-error" style="margin-top:8px;"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
                @error('gambar.*')
                    <div class="hp-error" style="margin-top:8px;"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>
        </div>

        {{-- Section konten informasi berisi textarea isi tulisan --}}
        <div class="hp-section">
            <div class="hp-section-header">
                <div class="section-icon icon-content"><i class="fas fa-align-left"></i></div>
                <div>
                    <h6>Konten Informasi</h6>
                    <p>Isi tulisan informasi secara lengkap</p>
                </div>
            </div>
            <div class="hp-section-body">
                <div>
                    <label class="hp-label">Konten <span style="color:var(--danger)">*</span></label>
                    <textarea name="konten"
                        class="hp-input {{ $errors->has('konten') ? 'is-invalid' : '' }}"
                        rows="12"
                        placeholder="Masukkan isi konten informasi" required>{{ old('konten', $informasi->konten) }}</textarea>
                    @error('konten')
                        <div class="hp-error"><i class="fas fa-exclamation-circle"></i> {{ $message }}</div>
                    @enderror
                </div>
            </div>

            {{-- Bar simpan di bagian bawah form dengan tombol batal dan update --}}
            <div class="hp-save-bar">
                <span class="hp-save-hint"><i class="fas fa-lock me-1"></i> Perubahan informasi akan langsung tersimpan ke sistem</span>
                <div style="display:flex; gap:10px; align-items:center;">
                    {{-- Tombol batal kembali ke halaman daftar informasi --}}
                    <a href="{{ route('admin.informasi.index') }}" class="hp-btn-cancel">
                        <i class="fas fa-times"></i> Batal
                    </a>
                    {{-- Tombol submit menyimpan perubahan data informasi --}}
                    <button type="submit" class="hp-btn-save">
                        <i class="fas fa-save"></i> Update Informasi
                    </button>
                </div>
            </div>
        </div>

    </form>
</div>

{{-- Script preview gambar baru yang dipilih sebelum form disubmit --}}
<script>
    /* Mendengarkan perubahan pada input file gambar */
    document.getElementById('inputGambar').addEventListener('change', function(e) {
        const grid = document.getElementById('previewGrid');
        grid.innerHTML = '';
        const file = e.target.files[0];

        /* Keluar lebih awal jika tidak ada file yang dipilih */
        if (!file) return;

        /* Validasi ukuran file tidak melebihi batas 10MB yang ditentukan */
        if (file.size > 10 * 1024 * 1024) {
            alert('Gambar "' + file.name + '" melebihi batas maksimal 10MB!');
            this.value = '';
            return;
        }

        /* Membaca file sebagai URL data lalu menampilkan thumbnail preview gambar */
        const reader = new FileReader();
        reader.onload = function(ev) {
            const item = document.createElement('div');
            item.className = 'preview-item';
            item.innerHTML = '<img src="' + ev.target.result + '" alt="Preview">';
            grid.appendChild(item);
        };
        reader.readAsDataURL(file);
    });
</script>

@endsection